import { Component, OnInit } from '@angular/core';
import { TenantService } from '../tenant.service';
import { TravellerService } from '../traveller.service';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {

  constructor(public travellerService:TravellerService,public tenantService:TenantService) { }

  ngOnInit(): void {
  }
    logout(){
    this.travellerService.setTravellerLoggedOut();
    }
    logoutt(){
      this.tenantService.setTenantLoggedOut();
      }
  

}
