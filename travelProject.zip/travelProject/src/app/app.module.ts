import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { RegisterComponent } from './register/register.component';
import { TenantregisterComponent } from './tenantregister/tenantregister.component';
import { LoginComponent } from './login/login.component';
import { TenantloginComponent } from './tenantlogin/tenantlogin.component';
import { NavbarComponent } from './navbar/navbar.component';
import { HomeComponent } from './home/home.component';
import { ShowimgComponent } from './showimg/showimg.component';
import { UploadimgComponent } from './uploadimg/uploadimg.component';
import { PlaceregistrationComponent } from './placeregistration/placeregistration.component';
import { DisplaytravellersComponent } from './displaytravellers/displaytravellers.component';
import { SearchcotravellerComponent } from './searchcotraveller/searchcotraveller.component';
import { TenanthousesComponent } from './tenanthouses/tenanthouses.component';
import { ProfileComponent } from './profile/profile.component';
import { UpdateComponent } from './update/update.component';
import { UpdatehouseComponent } from './updatehouse/updatehouse.component';
import { ReserveComponent } from './reserve/reserve.component';

@NgModule({
  declarations: [
    AppComponent,
    RegisterComponent,
    TenantregisterComponent,
    LoginComponent,
    TenantloginComponent,
    NavbarComponent,
    HomeComponent,
    ShowimgComponent,
    UploadimgComponent,
    PlaceregistrationComponent,
    DisplaytravellersComponent,
    SearchcotravellerComponent,
    TenanthousesComponent,
    ProfileComponent,
    UpdateComponent,
    UpdatehouseComponent,
    ReserveComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
