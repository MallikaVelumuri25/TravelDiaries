import { TestBed } from '@angular/core/testing';

import { CryptpasswordService } from './cryptpassword.service';

describe('CryptpasswordService', () => {
  let service: CryptpasswordService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CryptpasswordService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
