import { Component, OnInit } from '@angular/core';

import { TenantService } from '../tenant.service';

@Component({
  selector: 'app-uploadimg',
  templateUrl: './uploadimg.component.html',
  styleUrls: ['./uploadimg.component.css']
})
export class UploadimgComponent implements OnInit {
  imageUrl: string;
  fileToUpload: File = null;
  reader: FileReader;
  tenantidlocal:any;
  imageForm:any;
  tenant:any;
  constructor(private service: TenantService) {
    this.imageUrl = '/assets/img/default-image.png';
    
  }

  ngOnInit() {
    
    this.tenant = JSON.parse(localStorage.getItem("tenantdetails"));
    console.log(this.tenant);
  }

  handleFileInput(file: FileList){
    this.fileToUpload = file.item(0);
    this.reader = new FileReader();
    this.reader.readAsDataURL(this.fileToUpload);
    this.reader.onload = (event: any) => {
      this.imageUrl = event.target.result;
    };
  }
  OnSubmit(imageForm: any) {
    console.log(imageForm);
    
    
    console.log("tenantidlocal");
   
    console.log(imageForm);

    this.service.postFile(imageForm, this.fileToUpload,this.tenant).subscribe (
      data => {
        console.log('done');
        this.imageUrl = '/assets/Images/recipe.jpg';
      }
    );
  }


  
}

