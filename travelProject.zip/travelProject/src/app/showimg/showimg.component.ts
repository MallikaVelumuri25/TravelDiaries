import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TenantService } from '../tenant.service';

@Component({
  selector: 'app-showimg',
  templateUrl: './showimg.component.html',
  styleUrls: ['./showimg.component.css']
})
export class ShowimgComponent implements OnInit {
  houses:any;
  housedetails:any;
  _listFilter : string;
  filteredProducts:any;
  tenantDetails: any;
  get listFilter():string{
    return this._listFilter;

  }

  set listFilter(value:string){
    this._listFilter=value;
    this.filteredProducts=this.listFilter?this.performFilter(this.listFilter):null;
  }
  performFilter(filterBy:string):any{
    filterBy=filterBy.toLocaleLowerCase();
    return this.houses.filter((house:any)=>house.place.toLocaleLowerCase().indexOf(filterBy)!==-1);
  }
  constructor(private service: TenantService,private router :Router) {
    
   }

  ngOnInit(): void {
    this.service.getHouses().subscribe( (result: any) => {console.log(result); this.houses = result; });
    console.log(this.houses);
  }
  reserve(data:any){
    localStorage.setItem('housedetails',JSON.stringify(data));

    this.router.navigate(['reserveHouse']);
  }
  /*
  getdetails(data:any){
    console.log("in details")
    console.log(data);
    console.log(data.tenant.tenantId);
    console.log(data.tenant.tenantName);
    this.service.getdetails(data.tenant.tenantId).subscribe( (result: any) => {console.log(result); 
    this.tenantDetails=result;
    });
    console.log("hi");
  }*/
}
