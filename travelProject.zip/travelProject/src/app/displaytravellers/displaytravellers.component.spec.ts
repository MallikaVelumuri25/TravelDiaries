import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DisplaytravellersComponent } from './displaytravellers.component';

describe('DisplaytravellersComponent', () => {
  let component: DisplaytravellersComponent;
  let fixture: ComponentFixture<DisplaytravellersComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DisplaytravellersComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DisplaytravellersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
