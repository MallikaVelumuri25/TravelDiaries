import { Component, OnInit } from '@angular/core';
import { TravellerService } from '../traveller.service';

@Component({
  selector: 'app-displaytravellers',
  templateUrl: './displaytravellers.component.html',
  styleUrls: ['./displaytravellers.component.css']
})
export class DisplaytravellersComponent implements OnInit {
place:string;
data:any;
  constructor(private service: TravellerService) { }

  ngOnInit(): void {
    this.place=localStorage.getItem('place');
    this.service.getDetailsByPlace(this.place).subscribe((result: any) => { console.log(result);
      this.data=result;

     });
     console.log(this.data);
  }
  
}
