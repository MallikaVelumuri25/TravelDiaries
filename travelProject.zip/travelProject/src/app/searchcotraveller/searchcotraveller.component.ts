import { Component, OnInit } from '@angular/core';
import { TravellerService } from '../traveller.service';

@Component({
  selector: 'app-searchcotraveller',
  templateUrl: './searchcotraveller.component.html',
  styleUrls: ['./searchcotraveller.component.css']
})
export class SearchcotravellerComponent implements OnInit {
  toggleOn:any;
  reviewForm:any;
  travellers:any
  traveller:any;
  _listFilter : string;
  filteredProducts:any;
  reviews:any;
  get listFilter():string{
    return this._listFilter;

  }

  set listFilter(value:string){
    this._listFilter=value;
    this.filteredProducts=this.listFilter?this.performFilter(this.listFilter):null;
  }
  performFilter(filterBy:string):any{
    filterBy=filterBy.toLocaleLowerCase();
    return this.travellers.filter((details:any)=>details.travellerDestination.toLocaleLowerCase().indexOf(filterBy)!==-1);
  }
  constructor(private service:TravellerService) { 
    this.reviewForm={reviewContent:'',reviewDate:'',place:'',traveller:{}};
  }

  ngOnInit(): void {
    this.service.gettravellers().subscribe( (result: any) => {console.log(result); this.travellers = result; });
    console.log(this.travellers);
    this.traveller = JSON.parse(localStorage.getItem("travellerdetails"));
    this.reviewForm.traveller = this.traveller;
    this.service.getreviews().subscribe( (result: any) => {console.log(result); this.reviews = result; });
    console.log(this.reviews);
    
  }
  
  postreview(){
    
    this.reviewForm.place=this._listFilter;
    this.service.postreview(this.reviewForm).subscribe( (result: any) => {console.log(result); });
    this.toggleOn= true;
  }
  getItems() {
    return this.reviews.filter((review) => review.place=== this. _listFilter);
  }
}
