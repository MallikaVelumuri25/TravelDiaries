import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchcotravellerComponent } from './searchcotraveller.component';

describe('SearchcotravellerComponent', () => {
  let component: SearchcotravellerComponent;
  let fixture: ComponentFixture<SearchcotravellerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SearchcotravellerComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchcotravellerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
