import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { retry } from 'rxjs/operators';


@Injectable({
  providedIn: 'root'
})
export class TravellerService {
  mail(tenantMailId: any, subject: string, body: string) {
    return this.httpClient.get('RESTAPI_TRAVELDIARIES/webapi/myresource/mail/'+ tenantMailId + '/' + subject + '/' + body );  }
  updateDetails(traveller: any) {
    return this.httpClient.post('RESTAPI_TRAVELDIARIES/webapi/myresource/updateDetails/',  traveller);
   
  }
  private isTravellerLogged: any;
  setTravellerLoggedIn(): void { // login success
    this.isTravellerLogged = true;
   }
   setTravellerLoggedOut(): void { // logout success
    this.isTravellerLogged = false;
   }
   getTravellerLogged(): any {
     return this.isTravellerLogged;
   }
  getreviews() {
    return this.httpClient.get('RESTAPI_TRAVELDIARIES/webapi/myresource/getreviews').pipe(retry(10));

  }
  postreview(reviewForm: any) {
    console.log(reviewForm)
    return this.httpClient.post('RESTAPI_TRAVELDIARIES/webapi/myresource/postreview/',  reviewForm);
   
  }
  gettravellers() {
    return this.httpClient.get('RESTAPI_TRAVELDIARIES/webapi/myresource/gettravellers').pipe(retry(10));
  }
  getDetailsByPlace(place: any) {
    return this.httpClient.get('RESTAPI_TRAVELDIARIES/webapi/myresource/getDetailsByPlace/'+ place);
  
  }
  registerplace(place: any) {
    return this.httpClient.post('RESTAPI_TRAVELDIARIES/webapi/myresource/registerplace/',  place);
   
  }
  getTravellerByEmail(loginform: any) {
    
    return this.httpClient.get('RESTAPI_TRAVELDIARIES/webapi/myresource/getTravellerByEmail/'+ loginform.emailId);
  
  }
  getTravellerByUserPass(loginform: any) {
    //throw new Error('Method not implemented.');
    console.log(loginform);
    return this.httpClient.get('RESTAPI_TRAVELDIARIES/webapi/myresource/getTravellerByUserPass/'+ loginform.emailId + '/' + loginform.password);
   }
  
  //private isUserLogged: any;
  constructor(private httpClient: HttpClient) {
    //this.isUserLogged = false;
  }
  registertraveller(traveller: any) {
    console.log("dsjff")
    console.log(traveller)
    return this.httpClient.post('RESTAPI_TRAVELDIARIES/webapi/myresource/registertraveller/',  traveller);
   }

}
