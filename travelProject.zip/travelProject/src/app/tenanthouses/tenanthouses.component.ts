import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TenantService } from '../tenant.service';

@Component({
  selector: 'app-tenanthouses',
  templateUrl: './tenanthouses.component.html',
  styleUrls: ['./tenanthouses.component.css']
})
export class TenanthousesComponent implements OnInit {
  Id:any;
  data:any;
  tenant: any;
  houseDetails:any;
  constructor(private service:TenantService,private router : Router ) { }

  ngOnInit(): void {
    this.tenant=JSON.parse(localStorage.getItem('tenantdetails'));
    this.Id=this.tenant.tenantId;
    console.log(this.Id);
    this.service.getHouses().subscribe((result: any) => { console.log(result);
      this.data=result;

     });
     console.log(this.data);
     
  }
  getItems() {
    return this.data.filter((house) => house.tenant.tenantId=== this. Id);
  }
  updateHouseDetails(data:any){
    console.log(data);
    localStorage.setItem('houseDetails',JSON.stringify(data));
    this.router.navigate(['updateHouse']);

  }
}
