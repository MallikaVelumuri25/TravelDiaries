import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TenanthousesComponent } from './tenanthouses.component';

describe('TenanthousesComponent', () => {
  let component: TenanthousesComponent;
  let fixture: ComponentFixture<TenanthousesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TenanthousesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TenanthousesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
