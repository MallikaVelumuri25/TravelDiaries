import { Component, OnInit } from '@angular/core';
import { TravellerService } from '../traveller.service';
import { Router } from '@angular/router';
import { ViewChild,ElementRef } from '@angular/core'
import { CryptpasswordService } from '../cryptpassword.service' ;

/*import {MatSnackBar} from '@angular/material/snack-bar';*/

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  @ViewChild('loginRef', {static: true }) loginElement: ElementRef;
  //showMe:boolean=true
  name : string = null;
  auth2:any;
  loginform: any;
  retrivedData : any;
  travellerdetails:any;
  traveller:any;
  constructor( private pass : CryptpasswordService, private router : Router ,private service : TravellerService) {
    this.loginform = {emailId : '', password : ''};
    
   }

   ngOnInit() {
    this.googleInitialize();
  }
  /*toggleTag(){
    this.showMe=!this.showMe
  }*/
  

  googleInitialize() {
    window['googleSDKLoaded'] = () => {
      window['gapi'].load('auth2', () => {
        this.auth2 = window['gapi'].auth2.init({
          client_id: '755373677024-brinq0mslqr3f1dpv65agvcuts8soene.apps.googleusercontent.com',
          cookie_policy: 'single_host_origin',
          scope: 'profile email'
        });
        this.prepareLogin();
      });
    }
    (function(d, s, id){
      var js, fjs = d.getElementsByTagName(s)[0];
      if (d.getElementById(id)) {return;}
      js = d.createElement(s); js.id = id;
      js.src = "https://apis.google.com/js/platform.js?onload=googleSDKLoaded";
      fjs.parentNode.insertBefore(js, fjs);
    }(document, 'script', 'google-jssdk'));
  }

  prepareLogin() {
    this.auth2.attachClickHandler(this.loginElement.nativeElement, {},
      (googleUser) => {
        let profile = googleUser.getBasicProfile();
        console.log('Token || ' + googleUser.getAuthResponse().id_token);
        console.log('Image URL: ' + profile.getImageUrl());
        console.log('Email: ' + profile.getEmail());
        this.router.navigate(['home']);
      }, (error) => {
        alert(JSON.stringify(error, undefined, 2));
      });
  }
  EnCryptpassword(password : string){
    let encryptedText = this.pass.encrypt(password);
    //console.log(encryptedText);
    return encryptedText;
  }
  
  DeCryptpassword(password : string){
    let decryptedText = this.pass.decrypt(password);
    console.log(decryptedText);
    return decryptedText;
  }


  getTravellerByUserPass() {
    /*this.service.getTravellerByUserPass(this.loginform).subscribe((result: any) => {console.log(result); this.retrivedData = result;
    if(this.retrivedData === null){
      alert("Wrong Credentials");

    }
    else{
      alert("logged in");
      this.router.navigate(['home']);
      
      localStorage.setItem("TravellerDetails", this.retrivedData.travellerName);
    }
    });
*/
    
    console.log(this.DeCryptpassword("U2FsdGVkX1/jI8DNGs0snhaUGMQGxc68t/bXGA7M5xA="));
    let original_password = this.loginform.password;
    console.log("checking.....");
    console.log("loginform in login.ts............");
    
    console.log(this.loginform);
    this.service.getTravellerByEmail(this.loginform).subscribe((result: any) => {console.log(result); this.retrivedData = result;
     //console.log(this.retrivedData);
     
     console.log("hehehe...displayig password : )");
     console.log(this.DeCryptpassword(this.retrivedData.travellerPassword));
     let decrypted_pass = this.DeCryptpassword(this.retrivedData.travellerPassword);
     //console.log(decrypted_pass);
      if(/*this.loginform.password != decrypted_pass ||*/ this.retrivedData == null){
      alert("Wrong Credentials");
      }
      else{
        localStorage.setItem('travellerdetails',JSON.stringify(result));
        console.log(this.retrivedData);
        console.log("hehehe...displayig password : )");
        console.log(this.DeCryptpassword(this.retrivedData.travellerPassword));
        let message = "Logged in !!";
        let action = "";
        //alert(" looged successfully");
        /*this._snackBar.open(message, action, {
        duration: 2000,
      });*/
      //console.log(this.retrivedData.customerName);
      //this.name = this.retrivedData.customerName;
      localStorage.setItem('traveller',JSON.stringify(this.retrivedData));
      this.service.setTravellerLoggedIn();
      this.router.navigate(['home']);
    }
    });
    }
}
