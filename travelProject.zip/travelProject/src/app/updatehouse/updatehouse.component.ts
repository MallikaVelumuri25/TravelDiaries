import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TenantService } from '../tenant.service';

@Component({
  selector: 'app-updatehouse',
  templateUrl: './updatehouse.component.html',
  styleUrls: ['./updatehouse.component.css']
})
export class UpdatehouseComponent implements OnInit {
  houseDetails: any;
  fileToUpload: File;
  reader: FileReader;
  imageUrl: any;

  constructor(private service : TenantService,private router : Router) { }

  ngOnInit(): void {
    this.houseDetails = JSON.parse(localStorage.getItem('houseDetails'));

  }
  handleFileInput(file: FileList){
    this.fileToUpload = file.item(0);
    this.reader = new FileReader();
    this.reader.readAsDataURL(this.fileToUpload);
    this.reader.onload = (event: any) => {
      this.imageUrl = event.target.result;
    };
  }
  submitUpdateForm(){
    console.log(this.houseDetails);
    this.service.updateHouseDetails(this.houseDetails).subscribe((result: any) => { console.log(result); } );
    this.router.navigate(['tenanthouses']);
    //localStorage.setItem('traveller',JSON.stringify(this.houseDetails));
  }

}
