import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { retry } from 'rxjs/operators';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class TenantService {
  updateHouseDetails(houseDetails: any) {
    return this.httpClient.post('RESTAPI_TRAVELDIARIES/webapi/myresource/updateHouseDetails/',  houseDetails);
   
  }
  /*
  getHousesByTenantId(Id: any) {
    return this.httpClient.get('RESTAPI_TRAVELDIARIES/webapi/myresource/getHousesByTenantId/'+ Id);
  
  }*/
  private isTenantLogged: any;
  setTenantLoggedIn(): void { // login success
    this.isTenantLogged = true;
   }
   setTenantLoggedOut(): void { // logout success
    this.isTenantLogged = false;
   }
   getTenantLogged(): any {
     return this.isTenantLogged;
   }
  currentTenant:any;
  setCurrentTenant(data:any){
    this.currentTenant=data;
    console.log(this.currentTenant);
  }
  getCurrentTenant(){
    return this.currentTenant;
  }
  postFile(imageForm: any, fileToUpload: File,tenant:any) {
    // const endpoint='RESTAPI/webapi/myresource/';
    const formData: FormData = new FormData();
    
    formData.append('houseName', imageForm.houseName);
    formData.append('place', imageForm.place);
    formData.append('Address', imageForm.Address);
    formData.append('rent', imageForm.rent);
    formData.append('details', imageForm.details);
    formData.append('status', imageForm.status);
   formData.append('tenantId',tenant.tenantId );
    formData.append('houseImage', fileToUpload, fileToUpload.name);
    console.log("in ts...")
 console.log(tenant.tenantId);
    console.log( fileToUpload.name);
    return this.httpClient.post('RESTAPI_TRAVELDIARIES/webapi/myresource/uploadImage', formData);
 
  }
  /*
  getdetails(data:any){
    return this.httpClient.get('RESTAPI_TRAVELDIARIES/webapi/myresource/getTenantById/'+ data);
  
  }
  */
  getHouses() {
    return this.httpClient.get('RESTAPI_TRAVELDIARIES/webapi/myresource/getHouses').pipe(retry(10));
   }
   
  
  getTenantByEmail(loginform: any) {
    /*throw new Error('Method not implemented.');*/
    return this.httpClient.get('RESTAPI_TRAVELDIARIES/webapi/myresource/getTenantByEmail/'+ loginform.emailId);
  

  }
  //httpClient: any;
  constructor(private httpClient: HttpClient) {
    //this.isUserLogged = false;
  }
  getTenantByUserPass(loginform: any) {
    //throw new Error('Method not implemented.');
    console.log(loginform);
    return this.httpClient.get('RESTAPI_TRAVELDIARIES/webapi/myresource/getTenantByUserPass/'+ loginform.emailId + '/' + loginform.password);
   }
  registertenant(tenant: any) {
    console.log("dsjff")
    console.log(tenant)
    return this.httpClient.post('RESTAPI_TRAVELDIARIES/webapi/myresource/registertenant/',  tenant);
   }

  
}
