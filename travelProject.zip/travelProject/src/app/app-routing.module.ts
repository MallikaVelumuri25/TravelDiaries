import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DisplaytravellersComponent } from './displaytravellers/displaytravellers.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { PlaceregistrationComponent } from './placeregistration/placeregistration.component';
import { ProfileComponent } from './profile/profile.component';
import { RegisterComponent } from './register/register.component';
import { ReserveComponent } from './reserve/reserve.component';
import { SearchcotravellerComponent } from './searchcotraveller/searchcotraveller.component';
import { ShowimgComponent } from './showimg/showimg.component';
import { TenanthousesComponent } from './tenanthouses/tenanthouses.component';
import { TenantloginComponent } from './tenantlogin/tenantlogin.component';
import { TenantregisterComponent } from './tenantregister/tenantregister.component';
import { UpdateComponent } from './update/update.component';
import { UpdatehouseComponent } from './updatehouse/updatehouse.component';
import { UploadimgComponent } from './uploadimg/uploadimg.component';

const routes: Routes = [{path : 'loginTraveller' , component : LoginComponent},
                          {path : 'loginTenant' , component : TenantloginComponent} ,
                          {path : 'registerTraveller' , component : RegisterComponent} ,
                          {path : 'registerTenant' , component : TenantregisterComponent} , 
                          {path : 'home' , component : HomeComponent},
                          {path : 'upload' , component : UploadimgComponent},
                          {path : 'showimage' , component : ShowimgComponent},
                          {path : 'registerforplace',component:PlaceregistrationComponent},
                          {path : 'displaytravellers',component:DisplaytravellersComponent},
                          {path:'searchtravellers',component:SearchcotravellerComponent},
                          {path:'tenanthouses',component:TenanthousesComponent},
                          {path :'profile',component:ProfileComponent},
                          {path : 'update',component:UpdateComponent},
                          {path : 'updateHouse',component:UpdatehouseComponent},
                          {path : 'reserveHouse',component : ReserveComponent
                        }
              
                        ];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
