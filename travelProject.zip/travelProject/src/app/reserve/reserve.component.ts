import { Component, OnInit } from '@angular/core';
import { TravellerService } from '../traveller.service';

@Component({
  selector: 'app-reserve',
  templateUrl: './reserve.component.html',
  styleUrls: ['./reserve.component.css']
})
export class ReserveComponent implements OnInit {
  housedetails: any;
  traveller: any;
  reserveform: any;
  subject:string;
  body:string;
  userdate:Date;
  constructor(private service:TravellerService) { 
    this.reserveform={travellerName:'',date:'',days:''}
  }

  ngOnInit(): void {
    this.housedetails = JSON.parse(localStorage.getItem("housedetails"));
    this.traveller = JSON.parse(localStorage.getItem("travellerdetails"));
    this.reserveform.travellerName=this.traveller.travellerName;
    
    this.subject = "House Reservation";
    }
  submitReserveForm(){
    this.userdate=this.reserveform.date;
    this.body = this.reserveform.travellerName+" wants to reserve your house at "+this.housedetails.Address+" "+this.reserveform.place+ " for "+this.reserveform.days+" days from "+this.userdate+"..User contact Number: "+this.traveller.travellerPhoneNo+" user MailId: "+this.traveller.travellerGmailId;
    console.log(this.reserveform);
    console.log(this.body);
    console.log(this.traveller.travellerGmailId);
    this.service.mail(this.housedetails.tenant.tenantMailId,this.subject,this.body).subscribe();
    alert("you will receive a call back within 24hours")
  }
}
