import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TravellerService } from '../traveller.service';

@Component({
  selector: 'app-placeregistration',
  templateUrl: './placeregistration.component.html',
  styleUrls: ['./placeregistration.component.css']
})
export class PlaceregistrationComponent implements OnInit {
  place:any;
  traveller:any;
  data: any;
  constructor(private service: TravellerService,private router : Router) { 
    this.place={startingPoint:'',travellerDestination:'',date:'',days:'',traveller:{}};
  }

  ngOnInit(): void {
    this.traveller = JSON.parse(localStorage.getItem("travellerdetails"));
    this.place.traveller = this.traveller;
    console.log("in pr");
    console.log(this.place.traveller);
  }
  registerplace(){
    this.service.registerplace(this.place).subscribe((result: any) => { console.log(result); 
    alert("successfully registered");
    this.router.navigate(['displaytravellers']);
    localStorage.setItem('place',this.place.travellerDestination);
  });
  }
}
