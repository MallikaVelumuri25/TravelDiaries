import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PlaceregistrationComponent } from './placeregistration.component';

describe('PlaceregistrationComponent', () => {
  let component: PlaceregistrationComponent;
  let fixture: ComponentFixture<PlaceregistrationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PlaceregistrationComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PlaceregistrationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
