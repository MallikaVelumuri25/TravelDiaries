import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TenantService } from '../tenant.service';
import { ViewChild,ElementRef } from '@angular/core'
import { CryptpasswordService } from '../cryptpassword.service' ;

@Component({
  selector: 'app-tenantlogin',
  templateUrl: './tenantlogin.component.html',
  styleUrls: ['./tenantlogin.component.css']
})
export class TenantloginComponent implements OnInit {
  @ViewChild('loginRef', {static: true }) loginElement: ElementRef;
  name : string = null;
  auth2:any;
  loginform: any;
  retrivedData: any;
  tenantdetails:any;
  constructor(private pass : CryptpasswordService,private router : Router ,private service : TenantService) {
    this.loginform = {emailId : '', password : ''};
   }

  ngOnInit(): void {
    this.googleInitialize();
  }
  googleInitialize() {
    window['googleSDKLoaded'] = () => {
      window['gapi'].load('auth2', () => {
        this.auth2 = window['gapi'].auth2.init({
          client_id: '755373677024-brinq0mslqr3f1dpv65agvcuts8soene.apps.googleusercontent.com',
          cookie_policy: 'single_host_origin',
          scope: 'profile email'
        });
        this.prepareLogin();
      });
    }
    (function(d, s, id){
      var js, fjs = d.getElementsByTagName(s)[0];
      if (d.getElementById(id)) {return;}
      js = d.createElement(s); js.id = id;
      js.src = "https://apis.google.com/js/platform.js?onload=googleSDKLoaded";
      fjs.parentNode.insertBefore(js, fjs);
    }(document, 'script', 'google-jssdk'));
  }

  prepareLogin() {
    this.auth2.attachClickHandler(this.loginElement.nativeElement, {},
      (googleUser) => {
        let profile = googleUser.getBasicProfile();
        console.log('Token || ' + googleUser.getAuthResponse().id_token);
        console.log('Image URL: ' + profile.getImageUrl());
        console.log('Email: ' + profile.getEmail());
        this.router.navigate(['home']);
      }, (error) => {
        alert(JSON.stringify(error, undefined, 2));
      });
  }
  EnCryptpassword(password : string){
    let encryptedText = this.pass.encrypt(password);
    //console.log(encryptedText);
    return encryptedText;
  }
  
  DeCryptpassword(password : string){
    let decryptedText = this.pass.decrypt(password);
    console.log(decryptedText);
    return decryptedText;
  }
  getTenantByUserPass() {
    /*this.service.getTenantByUserPass(this.loginform).subscribe((result: any) => {console.log(result); this.retrivedData = result;
    if(this.retrivedData === null){
      alert("Wrong Credentials");

    }
    else{
      alert("logged in");
      this.router.navigate(['home']);
    }
    });*/
    
    this.service.getTenantByEmail(this.loginform).subscribe((result: any) => {console.log(result); this.retrivedData = result;
     
     let decrypted_pass = this.DeCryptpassword(this.retrivedData.tenantPassword);
    
      if(this.loginform.password != decrypted_pass || this.retrivedData == null){
      alert("Wrong Credentials");
      }
      else{
        this.service.setCurrentTenant(result);
        console.log(this.retrivedData);
        console.log("hehehe...displayig password : )");
        console.log(this.DeCryptpassword(this.retrivedData.tenantPassword));
        let message = "Logged in !!";
        let action = "";
        //alert(" looged successfully");
        
      
      this.name = this.retrivedData.customerName;
     
      localStorage.setItem('tenantdetails',JSON.stringify(result));
      this.service.setTenantLoggedIn();
      this.router.navigate(['home']);
    }
    });
    }
}
