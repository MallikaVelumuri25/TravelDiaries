import { Component, OnInit } from '@angular/core';
import { TenantService } from '../tenant.service';
import { Router } from '@angular/router';
import { CryptpasswordService } from '../cryptpassword.service' ;
@Component({
  selector: 'app-tenantregister',
  templateUrl: './tenantregister.component.html',
  styleUrls: ['./tenantregister.component.css']
})
export class TenantregisterComponent implements OnInit {

  tenant: any;
  constructor(private pass:CryptpasswordService,private router : Router ,private service: TenantService) {
    this.tenant = {tenantId: '', tenantName: '',tenantPhoneNo:'',tenantMailId:''
    ,tenantCity:'', tenantState: '', tenantCountry: '',tenantPassword:''};
  }
  
  ngOnInit(): void {
  }
  EnCryptpassword(password : string){
              
    console.log("pragnnaaaa");
  let encryptedText = this.pass.encrypt(password);
  console.log(encryptedText);
  return encryptedText;
  }
  DeCryptpassword(password : string){
  let decryptedText = this.pass.decrypt(password);
  console.log(decryptedText);
  return decryptedText;
  }
  register(): void {
    let  ep = this.EnCryptpassword(this.tenant.tenantPassword);
    this.tenant.tenantPassword = ep;
    this.service.registertenant(this.tenant).subscribe((result: any) => { console.log(result); } );
    console.log(this.tenant);
    this.router.navigate(['loginTenant']);
  }



}
