import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TravellerService } from '../traveller.service';

@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.css']
})
export class UpdateComponent implements OnInit {
  traveller: any;

  constructor(private service: TravellerService,private router : Router ) { }

  ngOnInit(): void {
    this.traveller = JSON.parse(localStorage.getItem("traveller"));
  }
  submitUpdateForm(){
    this.service.updateDetails(this.traveller).subscribe((result: any) => { console.log(result); } );
    this.router.navigate(['profile']);
    localStorage.setItem('traveller',JSON.stringify(this.traveller));
  }
}
