import { Component, OnInit } from '@angular/core';
import { TravellerService } from '../traveller.service';
import { Router } from '@angular/router';
import { ViewChild,ElementRef } from '@angular/core'
import { CryptpasswordService } from '../cryptpassword.service' ;
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  @ViewChild('loginRef', {static: true }) loginElement: ElementRef;

  auth2:any;
  traveller: any;
  constructor(private pass:CryptpasswordService, private router : Router ,private service: TravellerService) {
    this.traveller = {travellerId: '', travellerName: '',travellerDOB:'',travellerGender:''
    ,travellerGmailId:'', travellerCity: '', travellerState: '',travellerCountry:'' ,travellerPassword: '', 
    travellerPhoneNo: '',travellerAadharNo:''
    };
 
  }
  ngOnInit(): void {
    console.log("hkjk")
    this.googleInitialize();
  }
  googleInitialize() {
    window['googleSDKLoaded'] = () => {
      window['gapi'].load('auth2', () => {
        this.auth2 = window['gapi'].auth2.init({
          client_id: '755373677024-brinq0mslqr3f1dpv65agvcuts8soene.apps.googleusercontent.com',
          cookie_policy: 'single_host_origin',
          scope: 'profile email'
        });
        this.prepareLogin();
      });
    }
    (function(d, s, id){
      var js, fjs = d.getElementsByTagName(s)[0];
      if (d.getElementById(id)) {return;}
      js = d.createElement(s); js.id = id;
      js.src = "https://apis.google.com/js/platform.js?onload=googleSDKLoaded";
      fjs.parentNode.insertBefore(js, fjs);
    }(document, 'script', 'google-jssdk'));
  }

  prepareLogin() {
    this.auth2.attachClickHandler(this.loginElement.nativeElement, {},
      (googleUser) => {
        let profile = googleUser.getBasicProfile();
        console.log('Token || ' + googleUser.getAuthResponse().id_token);
        console.log('Image URL: ' + profile.getImageUrl());
        console.log('Email: ' + profile.getEmail());
        this.router.navigate(['home']);
      }, (error) => {
        alert(JSON.stringify(error, undefined, 2));
      });
  }
    EnCryptpassword(password : string){
              
      console.log("pragnnaaaa");
    let encryptedText = this.pass.encrypt(password);
    console.log(encryptedText);
    return encryptedText;
    }
    DeCryptpassword(password : string){
    let decryptedText = this.pass.decrypt(password);
    console.log(decryptedText);
    return decryptedText;
    }
  register(): void {
    let  ep = this.EnCryptpassword(this.traveller.travellerPassword);
    this.traveller.travellerPassword = ep;
    this.service.registertraveller(this.traveller).subscribe((result: any) => { console.log(result); } );
    console.log(this.traveller);
    this.router.navigate(['loginTraveller']);
    
    
    //alert("successfully registered");
  }


}
